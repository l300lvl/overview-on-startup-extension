const APPDISPLAY = 'show-apps-key';
